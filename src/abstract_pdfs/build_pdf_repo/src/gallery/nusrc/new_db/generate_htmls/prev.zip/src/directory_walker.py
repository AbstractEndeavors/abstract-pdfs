from .imports import *
from .template_registry import *
from .assembly import *
from .helpers import *
from .rendering import *
# ═══════════════════════════════════════════════════════════════
# Directory walker — the recursive orchestrator
# ═══════════════════════════════════════════════════════════════


@dataclass
class WalkConfig:
    """All the explicit wiring a walk needs."""
    site_root: str
    dry_run: bool
    templates: TemplateRegistry
    resolver: PathResolver
    doc_index: DocumentIndex


def _write_html(path: Path, html: str, label: str, dry_run: bool) -> None:
    if dry_run:
        print(f"[dry-run] {path}  [{label}]")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        print(f"wrote {path}  [{label}]")


def generate_for_directory(
    directory: Path,
    base_url: str,
    config: WalkConfig,
    recurse: bool = True,
) -> bool:
    """
    Generate index.html for this directory. Returns True if something was written.

    Decision order:
      1. Does this dir match a DB document with SEO? → viewer page
      2. Does this dir have a filesystem manifest?   → viewer page (filesystem fallback)
      3. Does this dir have info.json?               → image page
      4. Does this dir have children?                → gallery page
      5. Otherwise                                   → skip
    """
    out_file = directory / "index.html"

    # ── 1. DB document match → viewer page ──
    doc = config.doc_index.find_by_dir(directory)
    if doc:
        view = config.doc_index.assemble_view(
            doc.id, config.resolver, base_url
        )
        if view and view.pages:
            html = render_viewer(config.templates, view, config.site_root)
            _write_html(out_file, html, f"viewer, {len(view.pages)} pages", config.dry_run)
            # Viewer pages are leaves — don't recurse into their subdirs
            return True

    # ── 2. Filesystem manifest (not yet in DB) → viewer page ──
    # Preserves v5 behavior for dirs that haven't been ingested yet
##    manifest = load_manifest(directory)
##    if manifest:
##        html = _render_manifest_viewer(
##            directory, base_url, manifest, config
##        )
##        _write_html(out_file, html, f"viewer/manifest, {len(manifest)} pages", config.dry_run)
##        return True

    # ── 3. info.json → image page ──
    info_path = directory / "info.json"
    if info_path.exists():
        try:
            meta = json.loads(info_path.read_text())
            html = render_image_page(
                config.templates, meta, base_url,
                config.site_root, directory, config.resolver,
            )
            _write_html(out_file, html, "image page", config.dry_run)
            return True
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Bad info.json %s: %s", info_path, e)

    # ── 4. Branch dir with children → gallery ──
    children = child_dirs(directory)
    if not children:
        return False

    # Recurse first so child pages exist before we build the gallery
    if recurse:
        for child in children:
            child_url = f"{base_url.rstrip('/')}/{child.name}"
            generate_for_directory(child, child_url, config, recurse=True)

    # Build gallery cards for immediate children
    cards = [
        config.doc_index.make_card_for_dir(
            child,
            href=f"{base_url.rstrip('/')}/{child.name}/",
            resolver=config.resolver,
        )
        for child in children
    ]

    html = render_gallery(
        config.templates, cards, humanize(directory.name),
        base_url, config.site_root,
    )
    _write_html(out_file, html, f"gallery, {len(cards)} cards", config.dry_run)
    return True


def _render_manifest_viewer(
    directory: Path,
    base_url: str,
    manifest: list[dict],
    config: WalkConfig,
) -> str:
    """
    Render a viewer page from a filesystem manifest (not yet in DB).
    This is the backward-compat path for dirs that haven't been ingested.
    Uses the same viewer template, just assembles context differently.
    """
    title = humanize(directory.name)
    first = manifest[0]
    description = clean_text(
        first.get("longdesc") or first.get("caption") or "", 300
    )
    keywords_raw = set()
    for entry in manifest:
        for kw in entry.get("keywords_str", "").split(","):
            kw = kw.strip()
            if kw and len(kw) > 2:
                keywords_raw.add(kw)
    keywords = ", ".join(sorted(keywords_raw)[:30])
    keywords_list = sorted(keywords_raw)[:12]

    pages_js = []
    for i, entry in enumerate(manifest, 1):
        thumb = entry.get("social_meta", {}).get("og:image")
        pages_js.append({
            "n": i,
            "thumb": thumb or "",
            "text": entry.get("longdesc", "").strip(),
            "alt": entry.get("alt", "").split(" | ")[0] or f"Page {i}",
        })

    pdf_url = first.get("schema", {}).get("url", "")
    first_thumb = pages_js[0]["thumb"] if pages_js else ""

    schema = {
        "@context": "https://schema.org",
        "@type": "CreativeWork",
        "name": title,
        "description": description,
        "keywords": keywords,
        "url": pdf_url,
        "thumbnailUrl": first_thumb,
        "fileFormat": "application/pdf",
    }

    return config.templates.render(
        "viewer",
        title=title,
        description=description,
        keywords=keywords,
        canonical_url=base_url.rstrip("/") + "/",
        first_thumb=first_thumb,
        schema_json=json.dumps(schema, indent=2),
        site_root=config.site_root,
        total=len(pages_js),
        pdf_url=pdf_url,
        pages_json=json.dumps(pages_js, ensure_ascii=False),
        pdf_url_json=json.dumps(pdf_url),
        keywords_json=json.dumps(keywords_list),
    )

