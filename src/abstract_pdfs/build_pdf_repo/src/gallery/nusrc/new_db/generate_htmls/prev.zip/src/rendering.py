from .imports import *
from .template_registry import *
from .helpers import *
# ═══════════════════════════════════════════════════════════════
# Rendering — templates + context
# ═══════════════════════════════════════════════════════════════


def render_viewer(
    templates: TemplateRegistry,
    view: DocumentView,
    site_root: str,
) -> str:
    pages_js = [
        {
            "n": pv.page_number,
            "thumb": pv.image_url or "",
            "text": pv.text,
            "alt": pv.alt.split(" | ")[0] if pv.alt else f"Page {pv.page_number}",
        }
        for pv in view.pages
    ]
    keywords_list = [
        kw.strip()
        for kw in view.keywords.split(",")
        if kw.strip() and len(kw.strip()) > 2
    ][:12]
    schema = {
        "@context": "https://schema.org",
        "@type": "CreativeWork",
        "name": view.title,
        "description": clean_text(view.description, 300),
        "keywords": view.keywords,
        "url": view.pdf_url,
        "thumbnailUrl": view.thumbnail_url or "",
        "fileFormat": "application/pdf",
    }

    return templates.render(
        "viewer",
        title=view.title,
        description=clean_text(view.description, 300),
        keywords=view.keywords,
        canonical_url=view.canonical_url,
        first_thumb=pages_js[0]["thumb"] if pages_js else "",
        schema_json=json.dumps(schema, indent=2),
        site_root=site_root,
        total=len(view.pages),
        pdf_url=view.pdf_url,
        pages_json=json.dumps(pages_js, ensure_ascii=False),
        pdf_url_json=json.dumps(view.pdf_url),
        keywords_json=json.dumps(keywords_list),
    )


def render_gallery(
    templates: TemplateRegistry,
    cards: list[GalleryCard],
    title: str,
    base_url: str,
    site_root: str,
) -> str:
    canonical = base_url.rstrip("/") + "/"
    card_dicts = [
        {
            "title": c.title,
            "description": c.description,
            "image_url": c.image_url,
            "href": c.href,
            "tags": c.tags,
            "page_count": c.page_count,
        }
        for c in cards
    ]
    return templates.render(
        "gallery",
        page_title=title,
        canonical_url=canonical,
        breadcrumbs=breadcrumbs_html(base_url, site_root),
        heading=title,
        card_count=len(cards),
        cards=card_dicts,
    )


def render_image_page(
    templates: TemplateRegistry,
    meta: dict[str, Any],
    base_url: str,
    site_root: str,
    directory: Path,
    resolver: PathResolver,
) -> str:
    title = meta.get("title") or humanize(directory.name)
    alt = meta.get("alt") or title
    description = clean_text(
        meta.get("longdesc") or meta.get("caption") or "", 300
    )
    keywords = meta.get("keywords_str", "")
    img_url = (
        meta.get("schema", {}).get("url")
        or meta.get("social_meta", {}).get("og:image")
    )
    # Filesystem fallback for image
    if not img_url:
        img_url = first_image_url(directory, resolver)

    keyword_tags = [kw.strip() for kw in keywords.split(",") if kw.strip()]

    return templates.render(
        "image_page",
        title=title,
        alt=alt,
        description=description,
        keywords=keywords,
        keyword_tags=keyword_tags,
        img_url=img_url,
        og_image=img_url or "",
        schema_json=json.dumps(meta.get("schema", {}), indent=2),
        license=meta.get("license", ""),
        attribution=meta.get("attribution", ""),
        canonical_url=base_url.rstrip("/") + "/",
        breadcrumbs=breadcrumbs_html(base_url, site_root),
    )
